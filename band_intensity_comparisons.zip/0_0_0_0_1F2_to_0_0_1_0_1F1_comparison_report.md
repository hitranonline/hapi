# ExoMol vs HITRAN Intensity Comparison Report

## Executive Summary

- Requested ExoMol band: `0 0 0 0 1F2 -> 0 0 1 0 1F1`
- Chosen HITRAN band: `0 0 0 0 1A1 -> 0 0 1 0 1F2`
- Match status: `nearest_quanta_fallback`
- Interpretation: Nearest same-quanta fallback. This supports band-level intensity validation, but it is not a symmetry-resolved one-to-one check.

## Inputs

- ExoMol source: `D:\Github\hapi\exomol_ch4_mm_pure_nu3_band_texts_hitran_style_2500_3500_merged\EXOMOL_CH4_MM_pure_nu3_hitran_style_0_0_0_0_1F2_to_0_0_1_0_1F1_T296.0K.txt`
- HITRAN source: `D:\Github\hapi\ch4_nu3_progressions\band_line_texts\CH4_M6_I1_0_0_0_0_1A1_to_0_0_1_0_1F2.txt`

## Selected Band Comparison

### ExoMol

- Line count: 20735
- Strongest line wavenumber: 3067.164189 cm^-1
- Strongest line intensity: 1.333400e-19

### HITRAN

- Line count: 6489
- Strongest line wavenumber: 3067.300224 cm^-1
- Strongest line intensity: 2.114000e-19

### Band-Level Comparison Notes

- Strongest-line wavenumber difference: 0.136035 cm^-1
- Strongest-line intensity ratio ExoMol/HITRAN: 0.630747
- Plot file: `D:\Github\hapi\band_intensity_comparisons\0_0_0_0_1F2_to_0_0_1_0_1F1_intensity_overlay.html`

## Aggregate `nu3 0->1` Comparison

### ExoMol Aggregate

- Band count: 5
- Total line count: 55558
- Strongest line wavenumber: 3067.300224 cm^-1
- Strongest line intensity: 2.215029e-19

### HITRAN Aggregate

- Band count: 7
- Total line count: 11612
- Strongest line wavenumber: 3067.300224 cm^-1
- Strongest line intensity: 2.114000e-19

### Aggregate Comparison Notes

- Strongest-line wavenumber difference: 0.000000 cm^-1
- Strongest-line intensity ratio ExoMol/HITRAN: 1.047790
- Plot file: `D:\Github\hapi\band_intensity_comparisons\nu3_0_to_1_intensity_overlay.html`

## Assessment

- The selected comparison uses the nearest same-quanta HITRAN band, so the result should be treated as a same-band sanity check rather than an exact label validation.
- The aggregate `nu3 0->1` figure is the better high-level check of whether the ExoMol intensity distribution is broadly consistent with HITRAN in this spectral region.
